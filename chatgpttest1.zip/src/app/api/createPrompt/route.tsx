import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  try {
    // Fetch data from an external API or database
    const response = await fetch('https://localhost:3000') // Replace with your API endpoint 

    // Check for HTTP errors (status codes outside the 2xx range)
    if (!response.ok) {
      const errorData = await response.json() // Try to extract error details
      throw new Error(`API request failed with status ${response.status}: ${errorData.message || response.statusText}`)
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error(error) 
    return   
 NextResponse.json({ error: 'Failed to fetch data' }, { status: 500 }) 
  }
}