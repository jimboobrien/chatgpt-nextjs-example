
import MyComponent from '../components/apiCall';

export default function Home() {
  return (
      <div className="main_wrapper"> 
      <MyComponent/>
      </div>
  );
}
