'use client'
import { useState, useEffect } from 'react'

export default function MyComponent() {
  const [data, setData] = useState(null)

  useEffect(() => {
    const fetchData = async () => {
      const res = await fetch('/api/createPrompt') // Replace with your API endpoint 
      const data = await res.json()
      setData(data)
    }
    fetchData()
  }, [])

  if (!data) return <div>Loading...</div>

  return (
    <div>
      {/* Display the fetched data */}
      {data.map((item) => (
        <div key={item.id}>{item.name}</div>
      ))}
    </div>
  )
}